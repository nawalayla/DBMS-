﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AirlineReservationSystem
{
    public partial class Ticket : Form
    {
        SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=dbo;Integrated Security=True;Encrypt=False");
        string pname, ppass, pnat;

        public Ticket()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void fillPassenger()
        {
            conn.Open();
            SqlCommand command = new SqlCommand("select PassId from [dbo].[PassengerTbl]", conn);
            SqlDataReader rdr=command.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(rdr);
            Pid.ValueMember = "PassId";
            Pid.DataSource = dt;
            conn.Close();
        }
        private void fillFlightCode()
        {
            conn.Open();
            SqlCommand command = new SqlCommand("select FCode from [dbo].[FlightTbl]", conn);
            SqlDataReader rdr = command.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(rdr);
            Fcode.ValueMember = "FCode";
            Fcode.DataSource = dt;
            conn.Close();
        }
        private void Ticket_Load(object sender, EventArgs e)
        {
            fillPassenger();
            fillFlightCode();
            populate();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Fcode.SelectedItem.ToString() == "" || Pid.SelectedItem.ToString() == "" || PName.Text == "" || Tid.Text == "" || Amount.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    conn.Open();
                    string query = "insert into [dbo].[TicketTbl] (Tid,Fcode,Pid,Pname,ppass,pnation,amt) values('" + Tid.Text + "','" + Fcode.SelectedText + "','" + Pid.SelectedText + "','" + PName.Text + "','" + Passport.Text + "','" + Nat.Text + "','" + Amount.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Inserted Successfully");
                    conn.Close();
                    populate();
                }
                  
                
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }

            }
        }
        private void populate()
        {
            conn.Open();

            string query = "select* from [dbo].[TicketTbl]";
            SqlDataAdapter sda = new SqlDataAdapter(query, conn);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            TicketDGV.DataSource = ds.Tables[0];
            conn.Close();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Tid.Text = "";
            Nat.Text = "";
            Amount.Text = "";
            PName.Text = "";
            Passport.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Show();
            this.Hide();
        }

        private void fetchPassenger()
        {
            conn.Open();
            string query = "select *from [dbo].[PassengerTbl] where PassID =" + Pid.SelectedText + ";";
            SqlCommand cmd = new SqlCommand(query, conn);
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);

            foreach (DataRow dr in dt.Rows)
            {
                pname = dr["PassName"].ToString();
                ppass = dr["Passport"].ToString();
                pnat = dr["PassNat"].ToString();
                PName.Text = pname;
                Passport.Text = ppass;
                Nat.Text = pnat;
            }
                conn.Close();
        }

        private void Pid_SelectionChangeCommitted(object sender, EventArgs e)
        {
            fetchPassenger();
        }
    }
}
