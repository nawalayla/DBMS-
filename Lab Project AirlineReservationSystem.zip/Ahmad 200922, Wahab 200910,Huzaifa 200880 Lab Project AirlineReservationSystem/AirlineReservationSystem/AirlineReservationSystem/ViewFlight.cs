﻿using Sipaa.Framework;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace AirlineReservationSystem
{

    public partial class ViewFlight : Form
    {
        SqlConnection conn = new SqlConnection("Data Source =.; Initial Catalog = dbo; Integrated Security = True; Encrypt=False");


        public ViewFlight()
        {
            InitializeComponent();
        }

        private void ViewFlight_Load(object sender, EventArgs e)
        {
            populate();
        }
        private void populate()
        {
            conn.Open();

            string query = "select* from FlightTbl";
            SqlDataAdapter sda = new SqlDataAdapter(query, conn);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            
            var ds = new DataSet();
            sda.Fill(ds);
            FlightDGV.DataSource = ds.Tables[0];
            conn.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FCode.Text = "";
            SeatNum.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (FCode.Text == "")
            {
                MessageBox.Show("Enter the Flight Code");
            }
            else
            {
                try
                {
                    conn.Open();
                    string query = "delete from [dbo].[FlightTbl] where FCode = " + FCode.Text + ";";
                    SqlCommand cmd = new SqlCommand(query, conn);

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Flight Deleted Successfully");
                    conn.Close();
                    populate();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (FCode.Text == "" || SeatNum.Text == "" )
            {
                MessageBox.Show("Missing Info");
            }
            else
            {
                try
                {
                    conn.Open();
                    string query = "update [dbo].[FlightTbl] set FDate= '" + FDate.Value.ToString() + "', FDest='" + FDest.SelectedItem.ToString() + "', FSrc='" + FSrc.SelectedItem.ToString() + "', FCap='" + SeatNum.Text +  "' where FCode=" + FCode.Text;
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Updated Successfully");
                    conn.Close();
                    populate();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FlightTbl flight = new FlightTbl();
            flight.Show();
            this.Hide();
        }
    }
}
