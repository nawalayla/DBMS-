﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AirlineReservationSystem
{
    public partial class viewPassenger : Form
    {
        public viewPassenger()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=dbo;Integrated Security=True;Encrypt=False");

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
        private void populate()
        {
            conn.Open();

            string query = "select* from PassengerTbl";
            SqlDataAdapter sda = new SqlDataAdapter(query, conn);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            PassengerDGV.DataSource = ds.Tables[0];
            conn.Close();

        }
        private void viewPassenger_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AddPassenger add = new AddPassenger();
            add.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox3.Text=="")
            {
                MessageBox.Show("Enter the ID of Passenger");
            }
            else
            {
                try
                {
                    conn.Open();
                    string query = "delete from [dbo].[PassengerTbl] where PassId = " + textBox3.Text + ";";
                    SqlCommand cmd = new SqlCommand(query, conn);

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Passenger Deleted Successfully");
                    conn.Close();
                    populate();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void PassengerDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox3.Text = PassengerDGV.SelectedRows[0].Cells[0].Value.ToString();
            textBox4.Text = PassengerDGV.SelectedRows[0].Cells[1].Value.ToString();
            textBox1.Text = PassengerDGV.SelectedRows[0].Cells[2].Value.ToString();
            textBox2.Text = PassengerDGV.SelectedRows[0].Cells[3].Value.ToString();
            comboBox2.SelectedItem = PassengerDGV.SelectedRows[0].Cells[4].Value.ToString();
            comboBox1.SelectedItem = PassengerDGV.SelectedRows[0].Cells[5].Value.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            comboBox1.SelectedItem = "";
            comboBox2.SelectedItem = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text==""|| textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" )
            {
                MessageBox.Show("Missing Info");
            }
            else
            {
                try
                {
                    conn.Open();
                    string query = "update [dbo].[PassengerTbl] set PassName= '"+textBox4.Text+"', Passport='"+textBox1.Text+"', PassAd='"+textBox2.Text+"', PassNat='"+comboBox1.SelectedItem.ToString()+"', PassGend='"+comboBox2.SelectedItem.ToString()+"' where PassId="+textBox3.Text;
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Data Updated Successfully");
                    conn.Close();
                    populate();
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
